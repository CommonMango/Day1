using UnityEngine;

public interface IGameTimerObserver 
{
   public void OnTimerChanged(float curTime);
}
